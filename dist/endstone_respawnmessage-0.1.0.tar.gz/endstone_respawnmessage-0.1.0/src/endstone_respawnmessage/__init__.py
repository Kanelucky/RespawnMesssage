from endstone_respawnmessage.respawnMessage import respawnMessage

__all__ = ["respawnMessage"]